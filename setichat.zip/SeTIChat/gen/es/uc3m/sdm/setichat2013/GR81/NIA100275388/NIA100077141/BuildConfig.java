/** Automatically generated file. DO NOT MODIFY */
package es.uc3m.sdm.setichat2013.GR81.NIA100275388.NIA100077141;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}